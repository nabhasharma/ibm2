import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormComponent } from './form/form.component';
import { InvComponent } from './inv/inv.component';
import { InventoryBarComponent } from './inventory/inventory-bar/inventory-bar.component';

import { UserFormComponent } from './user-form/user-form.component';
import { UserListComponent } from './user-list/user-list.component';
import { InventoryTableComponent } from './inventory/inventory-table/inventory-table.component';



const routes: Routes = [
//   { path: '', redirectTo: '/home', pathMatch: 'full' },
//   {path:'home',component:FormTodoComponent,
//     children:[
//   {
// path:'registration',component:InventoryComponent},
//   ],
// }
{ path: '', component: FormComponent, pathMatch: 'full' },
  { path: 'muscles', component: FormComponent, pathMatch: 'full'},
  { path: 'muscles/add', component: InvComponent },
  {path:'inventory-bar',component:InventoryBarComponent},

  {path:'adduser',component:InventoryBarComponent},
  {path:'users',component:InventoryTableComponent},
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
