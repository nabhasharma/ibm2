import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
// import { InventoryComponent } from './form-todo/inventory/inventory.component';
// import { FormTodoComponent } from './form-todo/form-todo.component';/
import { FormComponent } from './form/form.component';
import { InvComponent } from './inv/inv.component';
import { InventoryBarComponent } from './inventory/inventory-bar/inventory-bar.component';
import { InventoryTableComponent } from './inventory/inventory-table/inventory-table.component';

import { HttpClientModule } from '@angular/common/http';
import { UserListComponent } from './user-list/user-list.component';
import { UserFormComponent } from './user-form/user-form.component';


@NgModule({
  declarations: [
    AppComponent, FormComponent, InvComponent, InventoryBarComponent, InventoryTableComponent,
    UserListComponent,
    UserFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
